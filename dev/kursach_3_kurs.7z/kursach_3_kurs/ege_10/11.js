(function () {
    'use strict';
    NAinfo.requireApiVersion(0, 0);
    
    let answers;
	let bone_one = sl(1,6);
	let bone_two = sl(1,6);
	let drop_no_name = ['одно очко', 'два очка', 'три очка', 'четыре очка', 'пять очков', 'шесть очков'];
	let drop_no_name_txt = drop_no_name[bone_one - 1];
	let bones_sum = sl(2,12);
	
	while(bones_sum == bone_one){
		bones_sum = sl(2,12);
	}
	
	if((bones_sum == 2)||(bones_sum == 12)){
		answers = 0.04;
	}
	
	if(drop_no_name_txt == 'одно очко'){
		if(bones_sum == 4){
			answers = 0.04;
		}
		if(bones_sum == 5){
			answers = 0.08;
		}
		if(bones_sum == 6){
			answers = 0.12;
		}
		if(bones_sum == 7){
			answers = 0.16;
		}
		if(bones_sum == 8){
			answers = 0.2;
		}
		if(bones_sum == 9){
			answers = 0.16;
		}
		if(bones_sum == 10){
			answers = 0.12;
		}
		if(bones_sum == 11){
			answers = 0.08;
		}		
	}
	
	if(drop_no_name_txt == 'два очка'){
		if(bones_sum == 4){
			answers = 0.08;
		}
		if(bones_sum == 5){
			answers = 0.08;
		}
		if(bones_sum == 6){
			answers = 0.12;
		}
		if(bones_sum == 7){
			answers = 0.16;
		}
		if(bones_sum == 8){
			answers = 0.12;
		}
		if(bones_sum == 9){
			answers = 0.16;
		}
		if(bones_sum == 10){
			answers = 0.12;
		}
		if(bones_sum == 11){
			answers = 0.08;
		}		
	}
	
	if(drop_no_name_txt == 'три очка'){
		if(bones_sum == 4){
			answers = 0.04;
		}
		if(bones_sum == 5){
			answers = 0.08;
		}
		if(bones_sum == 6){
			answers = 0.16;
		}
		if(bones_sum == 7){
			answers = 0.16;
		}
		if(bones_sum == 8){
			answers = 0.12;
		}
		if(bones_sum == 9){
			answers = 0.08;
		}
		if(bones_sum == 10){
			answers = 0.12;
		}
		if(bones_sum == 11){
			answers = 0.08;
		}		
	}
	
	if(drop_no_name_txt == 'четыре очка'){
		if(bones_sum == 3){
			answers = 0.08;
		}
		if(bones_sum == 4){
			answers = 0.12;
		}
		if(bones_sum == 5){
			answers = 0.08;
		}
		if(bones_sum == 6){
			answers = 0.12;
		}
		if(bones_sum == 7){
			answers = 0.16;
		}
		if(bones_sum == 8){
			answers = 0.16;
		}
		if(bones_sum == 9){
			answers = 0.08;
		}
		if(bones_sum == 10){
			answers = 0.04;
		}
		if(bones_sum == 11){
			answers = 0.08;
		}		
	}
	if(drop_no_name_txt == 'пять очков'){
		if(bones_sum == 3){
			answers = 0.08;
		}
		if(bones_sum == 4){
			answers = 0.12;
		}
		if(bones_sum == 5){
			answers = 0.16;
		}
		if(bones_sum == 6){
			answers = 0.12;
		}
		if(bones_sum == 7){
			answers = 0.16;
		}
		if(bones_sum == 8){
			answers = 0.12;
		}
		if(bones_sum == 9){
			answers = 0.08;
		}
		if(bones_sum == 10){
			answers = 0.08;
		}
		if(bones_sum == 11){
			answers = 0;
		}		
	}
	if(drop_no_name_txt == 'шесть очков'){
		if(bones_sum == 3){
			answers = 0.08;
		}
		if(bones_sum == 4){
			answers = 0.12;
		}
		if(bones_sum == 5){
			answers = 0.16;
		}
		if(bones_sum == 6){
			answers = 0.2;
		}
		if(bones_sum == 7){
			answers = 0.08;
		}
		if(bones_sum == 8){
			answers = 0.12;
		}
		if(bones_sum == 9){
			answers = 0.08;
		}
		if(bones_sum == 10){
			answers = 0.04;
		}
		if(bones_sum == 11){
			answers = 0;
		}		
	}	
	
    NAtask.setTask({
        text: 'Игральную кость бросили два раза. Известно, что ' + drop_no_name_txt + ' ' +
        'не выпало ни разу. Найдите при этом условии вероятность события «сумма очков равна ' + bones_sum + '»',
        
        answers,

    });
})();
