(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let shooter= ['стрелок', 'спортсмен', 'олимпиец', 'лучник', 'стрелец', 'арбалетчик'].iz();
	let qtion = ['попадёт в первую мишень и не попадёт в три последние', 'попадёт в первую и вторую мишень и не попадёт в две последние', 
	'попадёт в первую, вторую и третью мишень и не попадёт в последнюю', 'поразит все мишени'].iz();
	let p = sl(3,9) * 0.1;
	p = +p.toFixed(2);
	let answers;
	let shooter_up = shooter;
	let splitted = shooter_up.split("");
	let first = splitted[0].toUpperCase();
	let rest = [...splitted];
	rest.splice(0, 1);
	let result = [first, ...rest].join("");
	
	if (qtion == 'попадёт в первую мишень и не попадёт в три последние'){
		answers = p * (1 - p)**3;
	} else {
		if (qtion == 'попадёт в первую и вторую мишень и не попадёт в две последние'){
			answers = p**2 * (1 - p)**2;
		} else {
			if (qtion == 'попадёт в первую, вторую и третью мишень и не попадёт в последнюю'){
				answers = p ** 3 * (1 - p);
			} else {
				answers = p ** 4 ;
			}
		}
	}

	NAtask.setTask({
		
		text:''+result+' стреляет по одному разу в каждую из четырёх мишеней. ' +
		' Вероятность попадания в мишень при каждом отдельном выстреле равна ' + p + '. ' +
		' Найдите вероятность того, что '+shooter+' '+qtion+'',

		answers,

	});
})();
