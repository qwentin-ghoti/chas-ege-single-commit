(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let answers = 1;
	let storage_name = ['коробке', 'ящике', 'пенале', 'сумке', 'ранце'].iz();
	let item_name = sklonlxkand(['фломастер', 'карандаш', 'маркер', 'шарик', 'значок', 'кружок'].iz());
	let first_item = sl(2,6);
	let first_item_for_p = first_item;
	let second_item = sl(2,first_item);
	let second_item_for_p = second_item;
	let summ_items = first_item_for_p + second_item_for_p;
	let order = sl(1, first_item_for_p + 1);
	let order_name_list = ['первым' ,'вторым' ,'третьим' ,'четвертым' ,'пятым' ,'шестым' ,'седьмым'];
	let order_name = order_name_list[order - 1];
	let i = 1;
	
	
	while(i < order){
		answers	= answers * first_item / summ_items;
		first_item -= 1;
		summ_items -= 1;
		i++;
	}
	
	if(i == order){
		answers	= answers * second_item / summ_items;
	}
	
	answers = +answers.toFixed(3);
	NAtask.setTask({
		
		text:'В ' + storage_name + ' ' + chislitlx(first_item_for_p,item_name) + ' желтого и ' + chislitlx(second_item_for_p,item_name) + ' зеленого цвета. ' + item_name.vm + ' вытаскивают по очереди в случайном порядке.' +
		' Какова вероятность того, что первый раз зелёный ' + item_name.ie + ' появится ' + order_name + ' по счету. Ответ округлите до сотых.',



		answers,

	});
})();
