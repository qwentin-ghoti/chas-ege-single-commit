(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let place_name = ['Помещение', 'Цех', 'Класс', 'Подсобка', 'Комната', 'Кухня'].iz();
	let qtion = ['хотя бы одна лампа не перегорит','хотя бы две лампы не перегорят','три лампы не перегорят','перегорят все лампы'].iz();
	let p_fier = sl(10, 99) * 0.01;
		p_fier = +p_fier.toFixed(2);
	let	answers;
	if (qtion == 'перегорят все лампы'){
		answers = p_fier ** 3;
	} else {
		if (qtion == 'хотя бы одна лампа не перегорит'){
			answers = (p_fier ** 2 * (1 - p_fier)) + (p_fier  * (1 - p_fier) ** 2) + ((1 - p_fier) ** 3);
		} else {
			if (qtion == 'хотя бы две лампы не перегорят'){
				answers = (p_fier  * (1 - p_fier) ** 2) + ((1 - p_fier) ** 3);
			} else {
				answers = (1 - p_fier) ** 3 ;
			}
		}
	}
	
	
	NAtask.setTask({
		
		text:'' + place_name + ' освещается 3 лампами. Вероятность перегорания каждой лампы в течение года равна ' + p_fier + '.' +
		' Лампы перегорают независимо друг от друга. Найдите вероятность того, что в течение года ' + qtion + '.',
		
		answers,

	});
})();
