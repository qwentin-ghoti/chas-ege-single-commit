(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let shooter= sklonlxkand(['стрелок', 'спортсмен', 'олимпиец', 'лучник', 'стрелец', 'арбалетчик', 'мушкетер', 'канонир', 'артиллерист'].iz());
	let answers;
	let p_shoot = sl(10, 70);
	let p_shoot_end = sl(p_shoot + 10, 99) * 0.01;
	let p_counter = 1;
	let i = 1;
	p_shoot_end = +p_shoot_end.toFixed(2);
	p_shoot = p_shoot * 0.01;
	p_shoot = +p_shoot.toFixed(2);
		
	do{
		p_counter = 1 - (1 - p_shoot) ** i;
		i++;
	}while(p_counter < p_shoot_end);	
	
	answers = i - 1;
	
	NAtask.setTask({
		
		text:''+shooter.ie+' в тире стреляет по мишени до тех пор, пока не поразит её.' + 
			' Известно, что он попадает в цель с вероятностью '+p_shoot+' при каждом отдельном выстреле.' +
			' Какое наименьшее количество снарядов нужно дать '+shooter.de+', чтобы он поразил цель с вероятностью не меньше '+p_shoot_end+'.',
			
		answers,

	});
})();
//олимпиец, стрелец - неверно склоняется