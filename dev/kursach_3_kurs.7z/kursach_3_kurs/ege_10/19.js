(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let devaice = ['телефон', 'смартфон', 'КПК'].iz();
	let answers = 0;
	let p_messng = sl(10, 70) * 0.01;
	p_messng = +p_messng.toFixed(2);
	let steps = sl(2, 4);
	let i = 0;
	
	do{
		answers = answers + p_messng * (1 - p_messng) ** i;
		i++;
	}while(i < steps);

	answers = +answers.toFixed(1);
	
	NAtask.setTask({
		
		text:''+devaice+' передает sms-сообщение. В случае неудачи '+devaice+' делает следующую попытку.' +
		' Вероятность того, что сообщение удастся передать без ошибок при каждой попытке, равна '+p_messng+'.' +
		' Найдите вероятность того, что для передачи сообщения потребуется не больше '+steps+' попыток. Ответ округлите до десятых.',

		answers,

	});
})();
