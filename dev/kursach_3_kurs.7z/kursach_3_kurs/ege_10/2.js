(function() {
	NAinfo.requireApiVersion(0, 0);
	
	let number_of_tickets = 50;
	let first_teme = sl(5,20);
	let second_teme = sl(5,20);
	let answers;
	let be_or_not = ['будет', 'не будет'].iz();
	let first_teme_name = ['треугольники','трапеции','числа','степени','корни','логарифмы','уравнения','неравенства','функции','синусы','косинусы','дроби','проценты'].iz();
	let second_teme_name;
	
	do {
		 second_teme_name = ['треугольники','трапеции','числа','степени','корни','логарифмы','уравнения','неравенства','функции','синусы','косинусы','дроби','проценты'].iz();
	} while (first_teme_name == second_teme_name);
	
	if (be_or_not == 'будет') {
		answers = (first_teme + second_teme) / number_of_tickets;
	} else {
		answers = 1 - ((first_teme + second_teme) / number_of_tickets)
	}	

	NAtask.setTask({		
		text:'В сборнике билетов по математике всего '+number_of_tickets+' билетов: в '+first_teme+' билетах встречается про '+first_teme_name+',' +
		'в '+second_teme+' про '+second_teme_name+'. Билетов, в которых встречаются одновременно эти две темы, нет. ' +
		'Найдите вероятность того, что в случайном билете '+be_or_not+' про '+second_teme_name+' или про '+first_teme_name+'.',
		answers,
	});
})();
