(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let item_name = sklonlxkand(['батарейка', 'плата', 'крона', 'авторучка', 'ручка'].iz());
	let qtion = ['будет', 'не будет'].iz();
	let answers;
	let p_broken = sl(1, 12) * 0.01;
	let p_find_broken = sl(88, 99) * 0.01;
	let p_error = sl(1, 3) * 0.01;
	p_broken = +p_broken.toFixed(2);
	p_find_broken = +p_find_broken.toFixed(2);
	p_error = +p_error.toFixed(2);
	
	answers = p_broken * p_find_broken + (1 - p_broken) * p_error;
	
	if (qtion == 'не будет'){
		answers = 1 - answers;
	}
	
	NAtask.setTask({
		
		text:'Автоматическая линия изготавливает ' + item_name.im + '. Вероятность того, что готовая ' + item_name.ie + ' неисправна, равна ' + p_broken + '.' +
		' Перед упаковкой каждая ' + item_name.ie + ' проходит систему контроля качества. Вероятность того, что система забракует неисправную ' + item_name.ve + ', равна ' + p_find_broken + '.' +
		' Вероятность того, что система по ошибке забракует исправную ' + item_name.ve + ', равна ' + p_error + '.' +
		' Найдите вероятность того, что случайно выбранная изготовленная ' + item_name.ie + ' ' + qtion + ' забракована системой контроля.',

		answers,

	});
})();
