(function () {
    'use strict';
    NAinfo.requireApiVersion(0, 0);

    let rezultat=['не', 'действительно'].iz();
    let ill_true;
    let ill_false;
    let ill_pol;
    let answers = 0;
	let p_ill; 
	
	do{
		ill_true = sluchch(60, 95);
    	ill_false = sluchch(ill_true, 95);
    	ill_pol = sluchch(50, 78);
    	
		p_ill = (ill_pol + ill_false - 1) / (ill_true + ill_false - 1);
	
    	if (rezultat == 'действительно'){
    	    answers = p_ill * ill_true / ill_false;
    	} else {
    		answers = 1 - (p_ill * ill_true / ill_false);
    	}
	} while((answers < 0) && (answers < 1));
	
	answers = +answers.toFixed(2);
	
    NAtask.setTask({
        text: 'При подозрении на наличие некоторого заболевания пациента отправляют на ПЦР-тест.' +
        ' Если заболевание действительно есть, то тест подтверждает его в ' + ill_true + ' % случаев. Если заболевания нет,' +
        ' то тест выявляет отсутствие заболевания в среднем в ' + ill_false + '% случаев. Известно, что в среднем тест оказывается положительным у ' + ill_pol + '% пациентов,' +
        ' направленных на тестирование. При обследовании некоторого пациента врач направил его на ПЦР-тест, который оказался положительным.' +
    	' Какова вероятность того, что пациент ' + rezultat + ' имеет это заболевание? Ответ округлите до сотых.',
        answers,

    });
})();
