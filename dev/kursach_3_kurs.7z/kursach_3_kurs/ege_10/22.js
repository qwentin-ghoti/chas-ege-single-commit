(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let answers = 1;
	let storage_name = ['коробке', 'ящике', 'пенале', 'сумке', 'ранце'].iz();
	let item_name = sklonlxkand(['фломастер', 'карандаш', 'маркер', 'шарик', 'значок', 'кружок'].iz());
	let first_item = sl(2,10);
	let second_item = sl(3,10);
	let third_item = sl(4,10);
	let all_items = first_item + second_item + third_item;
	let color_one = sklonlxkand(['красный','оранжевый','желтый','зеленый','синий','голубой','белый','черный','серый','коричневый'].iz());
	let color_two = sklonlxkand(['красный','оранжевый','желтый','зеленый','синий','голубой','белый','черный','серый','коричневый'].iz());
	let color_three = sklonlxkand(['красный','оранжевый','желтый','зеленый','синий','голубой','белый','черный','серый','коричневый'].iz());
	while ((color_one == color_two)){
		color_two = sklonlxkand(['красный','оранжевый','желтый','зеленый','синий','голубой','белый','черный','серый','коричневый'].iz());
	}
	while ((color_one == color_three)&&(color_two == color_three)){
		color_three = sklonlxkand(['красный','оранжевый','желтый','зеленый','синий','голубой','белый','черный','серый','коричневый'].iz());
	}
	
	answers = (second_item / all_items * third_item / (all_items - 1)) + (third_item / all_items * second_item / (all_items - 1));
	answers = +answers.toFixed(2);
	
	NAtask.setTask({
		
		text:'В ' + storage_name + ' ' + first_item + ' ' + color_one.rm + ', ' + second_item + ' ' + color_two.rm + ' и ' + third_item + ' ' + color_three.rm + ' фломастеров. ' + 
			' Случайным образом выбирают два фломастера. Найдите вероятность того, что окажутся выбраны один ' + color_two.ie + ' и один ' + color_three.ie + ' фломастеры. Ответ округлите до сотых',



		answers,

	});
})();
//плохо склоняются цвета