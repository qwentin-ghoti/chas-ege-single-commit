(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
		let city_name= ['Тамбове', 'Воронеже', 'N', 'Москве', 'Туле', 'Челябинске', 'Абакане', 'Новомичуринске'].iz();
		let compliment_name = ['чашку кофе или десерт', 'чашку чая или десерт', 'чашку кофе', 'чашку чая', 'десерт'];
		let flips = 12;
		let point_one;
		let point_two;
		let answers;
		let proverka;
		
		function factorial(num) {
			if (num === 1) {
				return 1;
			} else if(num === 0){ 
				return 1;
			}else {
				return num * factorial(num - 1);
			}
		}		

		do {
			point_one = sl(2, 6);
			point_two = sl(1, point_one-1);
			answers =  (factorial(point_two) * factorial(flips - point_two)) / (factorial(point_one) * factorial(flips - point_one));
			proverka = (answers * 10000) % 100;
		} while (proverka !== 0);	
		
	NAtask.setTask({
		
		text:'Симметричную монету бросают '+flips+' раз. Во сколько раз вероятность события' +
		' «выпадет ровно '+chislitM(point_one,'орел','орла','орлов')+'» больше вероятности события «выпадет ровно  '+chislitM(point_two,'орел','орла','орлов')+'»?',
		answers,

	});
})();
