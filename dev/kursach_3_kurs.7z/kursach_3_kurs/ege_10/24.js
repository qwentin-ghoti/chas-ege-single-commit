(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
		let shooter= ['стрелок', 'спортсмен', 'олимпиец', 'лучник', 'стрелец', 'арбалетчик'].iz();
		let target_name = ['двум', 'трем', 'четырем', 'пяти', 'шести', 'семи', 'восьми'];
		let p_one_shot = sl(55, 95) * 0.01;
		p_one_shot = +p_one_shot.toFixed(2);
		let target_amount = sl(2,8);
		let target_name_for_text = target_name[target_amount - 2];
		let min_target = sl(2,target_amount - 1);
		let max_target = sl(min_target+1, target_amount);
		
		let p_target_one;
		let c_target_one;
		let p_target_two;
		let c_target_two;
		let answers = 1;
		
		function factorial(num) {
			if (num === 1) {
				return 1;
			} else if(num === 0){ 
				return 1;
			}else {
				return num * factorial(num - 1);
			}
		}
			
	let shooter_up = shooter;
		let splitted = shooter_up.split("");
		let first = splitted[0].toUpperCase();
		let rest = [...splitted];
		rest.splice(0, 1);
		let result = [first, ...rest].join("");
		
		let chance_hit_target = p_one_shot + p_one_shot * (1 - p_one_shot);
		let chance_no_hit_target = 1 - chance_hit_target;
		
		p_target_one = (chance_hit_target ** max_target) * (chance_no_hit_target ** (target_amount - max_target));
		c_target_one = factorial(target_amount) / (factorial(max_target) * factorial(target_amount - max_target));
		p_target_one = p_target_one * c_target_one;

		p_target_two = (chance_hit_target ** min_target) * (chance_no_hit_target ** (target_amount - min_target));
		c_target_two = factorial(target_amount) / (factorial(min_target) * factorial(target_amount - min_target));
		p_target_two = p_target_two * c_target_two;

		answers = p_target_one / p_target_two;
		answers = Math.round(answers);
	NAtask.setTask({
		
		text:''+result+' стреляет по '+target_name_for_text+' одинаковым мишеням. На каждую мишень дается не более двух выстрелов, ' +
		' и известно, что вероятность поразить мишень каждым отдельным выстрелом равна '+p_one_shot+'. ' +
		' Во сколько раз вероятность события «'+shooter+' поразит ровно '+max_target+' мишеней» ' +
		' больше вероятности события «'+shooter+' поразит ровно '+min_target+' мишени»? Ответ округлите до натурального числа.',
		answers,

	});
})();
