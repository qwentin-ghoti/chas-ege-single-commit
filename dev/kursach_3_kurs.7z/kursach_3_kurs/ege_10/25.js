(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
		let institution_name= sklonlxkand(['ресторан', 'кафе'].iz());
		let city_name= ['Тамбове', 'Воронеже', 'N', 'Москве', 'Туле', 'Челябинске', 'Абакане', 'Новомичуринске'].iz();
		let compliment_name = ['чашку кофе или десерт', 'чашку чая или десерт', 'чашку кофе', 'чашку чая', 'десерт'];
		let point_one = sl(1, 6);
		let point_two = sl(1, 6);
		let answers = 0.11;
		if (point_one == point_two){
			answers = 0.06;
		}
		
	NAtask.setTask({
		
		text:'В одном '+institution_name.pe+' в г. '+city_name+' администратор предлагает гостям сыграть в «Шеш-беш»: гость бросает одновременно 2 игральные кости. ' +
		' Если он выбросит комбинацию '+point_one+' и '+point_two+' очков хотя бы один раз из двух попыток, то получит комплимент от '+institution_name.re+':' +
		' чашку кофе или десерт бесплатно. Какова вероятность получить комплимент? Результат округлите до сотых.',
		answers,

	});
})();
