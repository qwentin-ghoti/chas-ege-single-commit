(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
	let gorod = ['городе', 'поселке', 'поселении', 'селе', 'колхозе', 'хуторе', 'провинции'].iz();
	let m_g = sklonlxkand(['мужчина', 'женщина'].iz());
	let vibor = 'выбран';
	let qtion = 'выбранный мужчина';
	let proverka;
	let percent_adult;
	let percent_old;
	let percent_old_men;
	
	if (m_g.ie == 'мужчина'){
		do {
			percent_adult = sl(40, 60);
			percent_old = sl(100, 200) * 0.1;
			percent_old = +percent_old.toFixed(2);
			percent_old_men = sl(10, 25);
			answers = (percent_old * 0.01 - (1 - percent_adult * 0.01) * (percent_old_men * 0.01)) / (percent_adult * 0.01) ;
			proverka = (answers * 10000) % 100;
		} while((proverka !== 0));
	}else{
		do {
			percent_adult = sl(40, 60);
			percent_old = sl(100, 200) * 0.1;
			percent_old = +percent_old.toFixed(2);
			percent_old_men = sl(10, 25);
			answers = (percent_old * 0.01 - (percent_adult * 0.01) * (percent_old_men * 0.01)) / (1 - percent_adult * 0.01) ;
			proverka = (answers * 10000) % 100;
		} while((proverka !== 0));
		vibor = 'выбранa';
		qtion = 'выбранная женщина';
	}

	NAtask.setTask({
		
		text:'В '+gorod+' '+percent_adult+'% взрослого населения— '+m_g.im+'. Пенсионеры составляют '+percent_old+'% взрослого населения,' +
		' причём доля пенсионеров среди '+m_g.rm+' равна '+percent_old_men+'%. Для социологического опроса '+vibor+' случайным образом '+m_g.ie+',' +
		' проживающая в этом городе. Найдите вероятность события «'+qtion+' является пенсионером».',

		answers,

	});
})();

