(function() {
	'use strict';
	NAinfo.requireApiVersion(0, 0);
	
		let item = ['сканер', 'принтер', 'телевизор', 'робот', 'бинокль', 'тренажёр', 'батуты', 'микроскоп', 'кофеварка', 'смартфон', 'аккумулятор', 'ноутбук', 'монитор', 'процессор', 'фотоаппарат'].iz();
		let f_year = sl(1,9);
		let s_year = sl(f_year + 1, 12);
		let s_year_chance =	sl(75, 85) ;
		let f_year_chance = (s_year_chance + sl(2, 14)) ;
		
		let answers = (f_year_chance - s_year_chance) * 0.01;

	NAtask.setTask({
		
		text:'Вероятность того, что новый '+item+' прослужит больше  '+chislitM(f_year,'годa','лет','лет')+', равна 0,'+f_year_chance+'. ' +
		' Вероятность того, что он прослужит больше '+chislitM(s_year,'годa','лет','лет')+', равна 0,'+s_year_chance+'. ' +
		' Найдите вероятность того, что он прослужит меньше '+chislitM(s_year,'годa','лет','лет')+', но больше '+chislitM(f_year,'годa','лет','лет')+'.',
		answers,

	});
})();
