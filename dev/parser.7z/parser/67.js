(function() {
	var distance=sl(1,40,1);
	var time1=sl(1,10,1);
	var time2=sl(1,8,1);
	var speedDifference=sl(1,10,1);
	var answer = (distance + speedDifference * time1 - speedDifference * time2)/time1;

	NAtask.setTask({
		text:'Дорога между пунктами А и В состоит из подъёма и спуска, а её длина равна '+distance+' км. Путь из А в В занял у туриста '+chislitlx(time1, 'час')+', из которых '+chislitlx(time2, 'час')+' ушло на спуск. Найдите скорость туриста на спуске, если она больше скорости на подъёме на '+speedDifference+' км/ч. Ответ дайте в км/ч',
		answers: answer,
	});
})();
