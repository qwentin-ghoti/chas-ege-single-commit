(function() { 'use strict'; retryWhileError(function() {
	/* По двум параллельным железнодорожным путям навстречу друг другу следуют скорый и пассажирский поезда, скорости которых равны соответственно 85 км/ч и 35 км/ч. Длина пассажирского поезда равна 250 метрам. Найдите длину скорого поезда, если время, за которое он прошёл мимо пассажирского, равно 30 секундам. Ответ дайте в метрах. */

	let n28=sl(1, 250, 1);
	let n50=sl(1, 30, 1);
	let n18=sl(1, 85, 1);
	let n21=sl(1, 35, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_railwayTrainType = sklonlxkand(decor.railwayTrainType.iz(2)); // ["скорый","пассажирский","товарный","почтовый","пожарный","пригородный","грузовой"]
	//let the_railwayTrainType = sklonlxkand(decor.railwayTrainType2.iz()); // ["скорый","медленный"]
	let the_railwayTrainGeneric = sklonlxkand(decor.railwayTrainGeneric.iz()); // ["поезд","состав"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'По двум параллельным железнодорожным путям навстречу друг другу следуют ' + the_railwayTrainType.ie +' и ' + the_railwayTrainType[0].ie +' ' + the_railwayTrainGeneric.re +', '+
			'скорости которых равны соответственно ' + n18 + ' км/ч и ' + n21 + ' км/ч. '+
			'Длина ' + the_railwayTrainType[0].re +' ' + the_railwayTrainGeneric.re +' равна ' + chislitlx(n28, 'метр', 'd') + '. ' + the_orderToFind.toZagl() +' длину ' + the_railwayTrainType.re +' ' + the_railwayTrainGeneric.re +', '+
			'если время, '+
			'за которое он прошёл мимо ' + the_railwayTrainType[0].re +', '+
			'равно ' + chislitlx(n50, 'секунда', 'd') + '. '+
			'Ответ дайте в метрах.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
