(function() { 'use strict'; retryWhileError(function() {
	/* Дорога между пунктами А и В состоит из подъёма и спуска, а её длина равна 22 км. Путь из А в В занял у туриста 8 часов, из которых 3 часа ушло на спуск. Найдите скорость туриста на спуске, если она больше скорости на подъёме на 2 км/ч? Ответ дайте в км/ч. */

	let n27=sl(1, 8, 1);
	let n35=sl(1, 3, 1);
	let n16=sl(1, 22, 1);
	let n57=sl(1, 2, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_pedestrianOnRoad = sklonlxkand(decor.pedestrianOnRoad.iz()); // ["пешеход","человек","турист","пионер","путешественник","дачник","колхозник","лесник"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'Дорога между ' + the_humanSettlementDestination.tm +' А и В состоит из подъёма и спуска, '+
			'а её длина равна ' + n16 + ' км. '+
			'Путь из А в В занял у ' + the_pedestrianOnRoad.re +' ' + chislitlx(n27, 'час') + ', '+
			'из которых ' + chislitlx(n35, 'час') + ' ушло на спуск. ' + the_orderToFind.toZagl() +' скорость ' + the_pedestrianOnRoad.re +' на спуске, '+
			'если она больше скорости на подъёме на ' + n57 + ' км/ч? Ответ дайте в км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
