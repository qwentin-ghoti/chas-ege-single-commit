(function() { 'use strict'; retryWhileError(function() {
	/* От пристани A к пристани B, расстояние между которыми равно 240 км, отправился с постоянной скоростью первый теплоход, а через 1 час после этого следом за ним, со скоростью на 1 км/ч большей, отправился второй. Найдите скорость первого теплохода, если в пункт B оба теплохода прибыли одновременно. Ответ дайте в км/ч. */

	let n23=sl(1, 1, 1);
	let n11=sl(1, 240, 1);
	let n37=sl(1, 1, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_berthForFloatingVehicle = sklonlxkand(decor.berthForFloatingVehicle.iz()); // ["пристань","причал"]
	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleM.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'От ' + the_berthForFloatingVehicle.im +' A к ' + the_berthForFloatingVehicle.im +' B, расстояние между которыми равно ' + n11 + ' км, '+
			'отправился с постоянной скоростью первый ' + the_activeFloatingVehicle.ie +', '+
			'а через ' + chislitlx(n23, 'час') + ' после этого следом за ним, '+
			'со скоростью на ' + n37 + ' км/ч большей, '+
			'отправился второй. ' + the_orderToFind.toZagl() +' скорость первого ' + the_activeFloatingVehicle.re +', '+
			'если в ' + the_humanSettlementDestination.ie +' B оба ' + the_activeFloatingVehicle.re +' прибыли одновременно. '+
			'Ответ дайте в км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
	NAtask.modifiers.variativeABC();
}, 2000);})();
// РешуЕГЭ: 
// 
