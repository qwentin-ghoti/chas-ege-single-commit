(function() { 'use strict'; retryWhileError(function() {
	/* Пристани A и B расположены на озере, расстояние между ними равно 264 км. Баржа отправилась с постоянной скоростью из A в B. На следующий день после прибытия она отправилась тем же путём обратно со скоростью на 2 км/ч больше прежней, сделав по пути остановку на 1 час. В результате она затратила на обратный путь столько же времени, сколько на путь из A в B. Найдите скорость баржи на пути из A в B. Ответ дайте в км/ч. , если после выключения телевизора прошло 21 с. */

	let n47=sl(1, 1, 1);
	let n12=sl(1, 264, 1);
	let n37=sl(1, 2, 1);
	let n93=sl(1, 21, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_berthForFloatingVehicle = sklonlxkand(decor.berthForFloatingVehicle.iz()); // ["пристань","причал"]
	let the_waterbodyWithoutCurrent = sklonlxkand(decor.waterbodyWithoutCurrent.iz()); // ["озеро","водохранилище"]
	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleF.iz()); // ["лодка","байдарка","баржа","яхта","моторная лодка"]
	let the_afterAWhile = decor.afterAWhile.iz(); // ["на следующий день","через день","в этот же день","через два дня","через три дня","через неделю"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_berthForFloatingVehicle.im.toZagl() +' A и B расположены на ' + the_waterbodyWithoutCurrent.pe +', '+
			'расстояние между ними равно ' + n12 + ' км. ' + the_activeFloatingVehicle.ie.toZagl() +' отправилась с постоянной скоростью из A в B. ' + the_afterAWhile.toZagl() +' после прибытия она отправилась тем же путём обратно со скоростью на ' + n37 + ' км/ч больше прежней, '+
			'сделав по пути остановку на ' + chislitlx(n47, 'час') + '. В результате она затратила на обратный путь столько же времени, '+
			'сколько на путь из A в B. ' + the_orderToFind.toZagl() +' скорость ' + the_activeFloatingVehicle.re +' на пути из A в B. Ответ дайте в км/ч., если после выключения телевизора прошло ' + n93 + ' с.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
	NAtask.modifiers.variativeABC();
}, 2000);})();
// РешуЕГЭ: 
// 
