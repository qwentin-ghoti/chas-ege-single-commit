(function() { 'use strict'; retryWhileError(function() {
	/* Теплоход, скорость которого в неподвижнойводе равна 27 км/ч, проходит некоторое расстояние по реке и после стоянки возвращается в исходный пункт. Скорость течения равна 1 км/ч, стоянка длится 5 часов, а в исходный пункт теплоход возвращается через 32 часа после отправления из него. Сколько километров проходит теплоход за весь рейс? */

	let n31=sl(1, 5, 1);
	let n44=sl(1, 32, 1);
	let n7=sl(1, 27, 1);
	let n26=sl(1, 1, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleM.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_activeFloatingVehicle.ie.toZagl() +', '+
			'скорость которого в неподвижнойводе равна ' + n7 + ' км/ч, '+
			'проходит некоторое расстояние по реке и после стоянки возвращается в исходный ' + the_humanSettlementDestination.ie +'. '+
			'Скорость течения равна ' + n26 + ' км/ч, '+
			'стоянка длится ' + chislitlx(n31, 'час') + ', '+
			'а в исходный ' + the_humanSettlementDestination.ie +' ' + the_activeFloatingVehicle.ie +' возвращается через ' + chislitlx(n44, 'час') + ' после отправления из него. '+
			'Сколько километров проходит ' + the_activeFloatingVehicle.ie +' за весь рейс?',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
