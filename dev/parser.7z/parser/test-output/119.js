(function() { 'use strict'; retryWhileError(function() {
	/* Теплоход проходит по течению реки до пункта назначения 384 км и после стоянки возвращается в пункт отправления. Найдите скорость теплохода в неподвижной воде, если скорость течения равна 4 км/ч, стоянка длится 8 часов, а в пункт отправления теплоход возвращается через 48 часов. Ответ дайте в км/ч. */

	let n34=sl(1, 8, 1);
	let n47=sl(1, 48, 1);
	let n8=sl(1, 384, 1);
	let n29=sl(1, 4, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleM.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_activeFloatingVehicle.ie.toZagl() +' проходит по течению реки до ' + the_humanSettlementDestination.re +' назначения ' + n8 + ' км и после стоянки возвращается в ' + the_humanSettlementDestination.ie +' отправления. ' + the_orderToFind.toZagl() +' скорость ' + the_activeFloatingVehicle.re +' в неподвижной воде, '+
			'если скорость течения равна ' + n29 + ' км/ч, '+
			'стоянка длится ' + chislitlx(n34, 'час') + ', '+
			'а в ' + the_humanSettlementDestination.ie +' отправления ' + the_activeFloatingVehicle.ie +' возвращается через ' + chislitlx(n47, 'час') + '. '+
			'Ответ дайте в км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
