(function() { 'use strict'; retryWhileError(function() {
	/* Моторная лодка прошла против течения реки 48 км и вернулась в пункт отправления, затратив на обратный путь на 8 часов меньше. Найдите скорость течения, если скорость лодки в неподвижной воде равна 8 км/ч. Ответ дайте в км/ч. */

	let n18=sl(1, 8, 1);
	let n5=sl(1, 48, 1);
	let n36=sl(1, 8, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]
	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz(2)); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleF.iz(2)); // ["лодка","байдарка","баржа","яхта","моторная лодка"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_activeFloatingVehicle[1].ie.toZagl() +' прошла против течения реки ' + n5 + ' км и вернулась в ' + the_humanSettlementDestination.ie +' отправления, '+
			'затратив на обратный путь на ' + chislitlx(n18, 'час') + ' меньше. ' + the_orderToFind.toZagl() +' скорость течения, '+
			'если скорость ' + the_activeFloatingVehicle[0].re +' в неподвижной воде равна ' + n36 + ' км/ч. '+
			'Ответ дайте в км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
