(function() { 'use strict'; retryWhileError(function() {
	/* Катер в 10:00 вышел по течению реки из пункта А в пункт В, расположенный в 15 км от А. Пробыв в пункте В 1 час, катер отправился назад и вернулся в пункт А в 15:00 того же дня. Определите собственную скорость катера (в км/ч), если известно, что скорость течения реки 2 км/ч. */

	let n25=sl(1, 1, 1);
	let minutes2=sl(30, 600, 30);
	let minutes40=sl(30, 900, 30);
	let n16=sl(1, 15, 1);
	let n59=sl(1, 2, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleM.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_activeFloatingVehicle.ie.toZagl() +' в ' + minutes2.toDvoet() + ' вышел по течению реки из ' + the_humanSettlementDestination.re +' А в ' + the_humanSettlementDestination.ie +' В, расположенный в ' + n16 + ' км от А. Пробыв в ' + the_humanSettlementDestination.pe +' В ' + chislitlx(n25, 'час') + ', ' + the_activeFloatingVehicle.ie +' отправился назад и вернулся в ' + the_humanSettlementDestination.ie +' А в ' + minutes40.toDvoet() + ' того же дня. ' + the_orderToFind.toZagl() +' собственную скорость ' + the_activeFloatingVehicle.re +'(в км/ч), если известно, '+
			'что скорость течения реки ' + n59 + ' км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
