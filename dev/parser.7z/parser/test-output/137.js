(function() { 'use strict'; retryWhileError(function() {
	/* Баржа в 10:00 вышлаиз пункта А в пункт В, расположенный в 30 км от А. Пробыв в пункте В 4 часа, баржа отправилась назад и вернулась в пункт А в 22:00 того же дня. Определите (в км/ч) скорость течения реки, если известно, что собственная скорость баржи равна 8 км/ч. */

	let n21=sl(1, 4, 1);
	let minutes2=sl(30, 600, 30);
	let minutes36=sl(30, 1320, 30);
	let n12=sl(1, 30, 1);
	let n57=sl(1, 8, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleF.iz()); // ["лодка","байдарка","баржа","яхта","моторная лодка"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_activeFloatingVehicle.ie.toZagl() +' в ' + minutes2.toDvoet() + ' вышлаиз ' + the_humanSettlementDestination.re +' А в ' + the_humanSettlementDestination.ie +' В, расположенный в ' + n12 + ' км от А. Пробыв в ' + the_humanSettlementDestination.pe +' В ' + chislitlx(n21, 'час') + ', ' + the_activeFloatingVehicle.ie +' отправилась назад и вернулась в ' + the_humanSettlementDestination.ie +' А в ' + minutes36.toDvoet() + ' того же дня. ' + the_orderToFind.toZagl() +'(в км/ч) скорость течения реки, '+
			'если известно, '+
			'что собственная скорость ' + the_activeFloatingVehicle.re +' равна ' + n57 + ' км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
