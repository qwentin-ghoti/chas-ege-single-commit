(function() { 'use strict'; retryWhileError(function() {
	/* Байдарка в 07:00 вышла из пункта А в пункт В, расположенный в 30 км от А. Пробыв в пункте В 2 часа 40 минут, байдарка отправилась назад и вернулась в пункт А в 23:00 того же дня. Определите (в км/ч) собственную скорость байдарки, если известно, что скорость течения реки равна 3 км/ч. */

	let n22=sl(1, 2, 1);
	let n27=sl(1, 40, 1);
	let minutes2=sl(30, 420, 30);
	let minutes42=sl(30, 1380, 30);
	let n13=sl(1, 30, 1);
	let n63=sl(1, 3, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleF.iz()); // ["лодка","байдарка","баржа","яхта","моторная лодка"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_activeFloatingVehicle.ie.toZagl() +' в ' + minutes2.toDvoet() + ' вышла из ' + the_humanSettlementDestination.re +' А в ' + the_humanSettlementDestination.ie +' В, расположенный в ' + n13 + ' км от А. Пробыв в ' + the_humanSettlementDestination.pe +' В ' + chislitlx(n22, 'час') + ' ' + chislitlx(n27, 'минута') + ', ' + the_activeFloatingVehicle.ie +' отправилась назад и вернулась в ' + the_humanSettlementDestination.ie +' А в ' + minutes42.toDvoet() + ' того же дня. ' + the_orderToFind.toZagl() +'(в км/ч) собственную скорость ' + the_activeFloatingVehicle.re +', '+
			'если известно, '+
			'что скорость течения реки равна ' + n63 + ' км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
