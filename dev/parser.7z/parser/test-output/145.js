(function() { 'use strict'; retryWhileError(function() {
	/* Лодка в 8:00 вышла из пункта А в пункт В, расположенный в 30 км от А. Пробыв в пункте В 1 час 30 минут, лодка отправилась назад и вернулась в пункт А в 22:00 того же дня. Определите (в км/ч) скорость течения реки, если известно, что собственная скорость лодки равна 5 км/ч. */

	let n22=sl(1, 1, 1);
	let n27=sl(1, 30, 1);
	let minutes2=sl(30, 480, 30);
	let minutes42=sl(30, 1320, 30);
	let n13=sl(1, 30, 1);
	let n63=sl(1, 5, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleF.iz()); // ["лодка","байдарка","баржа","яхта","моторная лодка"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_activeFloatingVehicle.ie.toZagl() +' в ' + minutes2.toDvoet() + ' вышла из ' + the_humanSettlementDestination.re +' А в ' + the_humanSettlementDestination.ie +' В, расположенный в ' + n13 + ' км от А. Пробыв в ' + the_humanSettlementDestination.pe +' В ' + chislitlx(n22, 'час') + ' ' + chislitlx(n27, 'минута') + ', ' + the_activeFloatingVehicle.ie +' отправилась назад и вернулась в ' + the_humanSettlementDestination.ie +' А в ' + minutes42.toDvoet() + ' того же дня. ' + the_orderToFind.toZagl() +'(в км/ч) скорость течения реки, '+
			'если известно, '+
			'что собственная скорость ' + the_activeFloatingVehicle.re +' равна ' + n63 + ' км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
