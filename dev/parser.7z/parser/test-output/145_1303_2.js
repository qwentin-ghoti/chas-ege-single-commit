(function() { 'use strict'; retryWhileError(function() {
	/* Расстояние между пристанями A и B равно 160 км. Из A в B по течению реки отправился плот, а через 1 час вслед за ним отправилась яхта, которая, прибыв в пункт B, тотчас повернула обратно и возвратилась в A. К этому времени плот проплыл 39 км. Найдите скорость яхты в неподвижной воде, если скорость течения реки равна 3 км/ч. Ответ дайте в км/ч. */

	let n22=sl(1, 1, 1);
	let n7=sl(1, 160, 1);
	let n53=sl(1, 39, 1);
	let n68=sl(1, 3, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_berthForFloatingVehicle = sklonlxkand(decor.berthForFloatingVehicle.iz()); // ["пристань","причал"]
	let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicle.iz()); // ["пароход","теплоход","каяк","корабль","паром","катер","лодка","байдарка","баржа","яхта","моторная лодка"]
	//let the_activeFloatingVehicle = sklonlxkand(decor.activeFloatingVehicleF.iz()); // ["лодка","байдарка","баржа","яхта","моторная лодка"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'Расстояние между ' + the_berthForFloatingVehicle.tm +' A и B равно ' + n7 + ' км. '+
			'Из A в B по течению реки отправился плот, '+
			'а через ' + chislitlx(n22, 'час') + ' вслед за ним отправилась ' + the_activeFloatingVehicle.ie +', '+
			'которая, '+
			'прибыв в ' + the_humanSettlementDestination.ie +' B, тотчас повернула обратно и возвратилась в A. К этому времени плот проплыл ' + n53 + ' км. ' + the_orderToFind.toZagl() +' скорость ' + the_activeFloatingVehicle.re +' в неподвижной воде, '+
			'если скорость течения реки равна ' + n68 + ' км/ч. '+
			'Ответ дайте в км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
	NAtask.modifiers.variativeABC();
}, 2000);})();
// РешуЕГЭ: 
// 
