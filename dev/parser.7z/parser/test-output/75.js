(function() { 'use strict'; retryWhileError(function() {
	/* Велосипедист выехал с постоянной скоростью из города А в город В, расстояние между которыми равно 156 км. На следующий день он отправился обратно со скоростью на 1 км/ч больше прежней. По дороге он сделал остановку на 1 час. В результате он затратил на обратный путь столько же времени, сколько на путь из А в В. Найдите скорость велосипедиста на пути из А в В. Ответ дайте в км/ч. */

	let n37=sl(1, 1, 1);
	let n16=sl(1, 156, 1);
	let n26=sl(1, 1, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_vehicleRacingOnRoad = sklonlxkand(decor.vehicleRacingOnRoad.iz()); // ["автомобиль","мотоцикл","велосипед","электросамокат","гироскутер","мотоциклист","велосипедист","машина","гонщик","грузовик","автомобилист"]
	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_afterAWhile = decor.afterAWhile.iz(); // ["на следующий день","через день","в этот же день","через два дня","через три дня","через неделю"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'' + the_vehicleRacingOnRoad.ie.toZagl() +' выехал с постоянной скоростью из ' + the_humanSettlementDestination.re +' А в ' + the_humanSettlementDestination.ie +' В, расстояние между которыми равно ' + n16 + ' км. ' + the_afterAWhile.toZagl() +' он отправился обратно со скоростью на ' + n26 + ' км/ч больше прежней. '+
			'По дороге он сделал остановку на ' + chislitlx(n37, 'час') + '. В результате он затратил на обратный путь столько же времени, '+
			'сколько на путь из А в В. ' + the_orderToFind.toZagl() +' скорость ' + the_vehicleRacingOnRoad.re +' на пути из А в В. Ответ дайте в км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
