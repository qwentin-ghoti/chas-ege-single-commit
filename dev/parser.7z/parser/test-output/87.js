(function() { 'use strict'; retryWhileError(function() {
	/* Из пункта А в пункт В, расстояние между которыми 50 км, одновременно выехали автомобилист и велосипедист. За час автомобилист проезжает на 30 км больше, чем велосипедист. Определите скорость велосипедиста, если известно, что он прибыл в пункт В на 1 час 30 минут позже автомобилиста. Ответ дайте в км/ч. */

	let n45=sl(1, 1, 1);
	let n50=sl(1, 30, 1);
	let n10=sl(1, 50, 1);
	let n24=sl(1, 30, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]
	let the_vehicleRacingOnRoad = sklonlxkand(decor.vehicleRacingOnRoad.iz(2)); // ["автомобиль","мотоцикл","велосипед","электросамокат","гироскутер","мотоциклист","велосипедист","машина","гонщик","грузовик","автомобилист"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'Из ' + the_humanSettlementDestination.re +' А в ' + the_humanSettlementDestination.ie +' В, расстояние между которыми ' + n10 + ' км, '+
			'одновременно выехали ' + the_vehicleRacingOnRoad[0].ie +' и ' + the_vehicleRacingOnRoad[1].ie +'. '+
			'За час ' + the_vehicleRacingOnRoad[0].ie +' проезжает на ' + n24 + ' км больше, '+
			'чем ' + the_vehicleRacingOnRoad[1].ie +'. ' + the_orderToFind.toZagl() +' скорость ' + the_vehicleRacingOnRoad[1].re +', '+
			'если известно, '+
			'что он прибыл в ' + the_humanSettlementDestination.ie +' В на ' + chislitlx(n45, 'час') + ' ' + chislitlx(n50, 'минута') + ' позже ' + the_vehicleRacingOnRoad[0].re +'. '+
			'Ответ дайте в км/ч.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
