(function() { 'use strict'; retryWhileError(function() {
	/* Расстояние между городами A и B равно 420 км. Из города A в город B выехал автомобиль, а через 1 час следом за ним со скоростью 80 км/чвыехал мотоциклист, догнал автомобиль в городе C и повернул обратно. Когда он вернулся в A, автомобиль прибыл в B. Найдите расстояние от A до C. Ответ дайте в километрах. */

	let n21=sl(1, 1, 1);
	let n7=sl(1, 420, 1);
	let n31=sl(1, 80, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_orderToFind = decor.orderToFind.iz(); // ["найдите","определите","вычислите"]
	let the_vehicleRacingOnRoad = sklonlxkand(decor.vehicleRacingOnRoad.iz(2)); // ["автомобиль","мотоцикл","велосипед","электросамокат","гироскутер","мотоциклист","велосипедист","машина","гонщик","грузовик","автомобилист"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'Расстояние между ' + the_humanSettlementDestination.tm +' A и B равно ' + n7 + ' км. '+
			'Из ' + the_humanSettlementDestination.re +' A в ' + the_humanSettlementDestination.ie +' B выехал ' + the_vehicleRacingOnRoad[0].ie +', '+
			'а через ' + chislitlx(n21, 'час') + ' следом за ним со скоростью ' + n31 + ' км/чвыехал ' + the_vehicleRacingOnRoad[1].ie +', '+
			'догнал ' + the_vehicleRacingOnRoad[0].ie +' в ' + the_humanSettlementDestination.pe +' C и повернул обратно. '+
			'Когда он вернулся в A, ' + the_vehicleRacingOnRoad[0].ie +' прибыл в B. ' + the_orderToFind.toZagl() +' расстояние от A до C. Ответ дайте в километрах.',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
	NAtask.modifiers.variativeABC();
}, 2000);})();
// РешуЕГЭ: 
// 
