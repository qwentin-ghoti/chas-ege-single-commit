(function() { 'use strict'; retryWhileError(function() {
	/* Из городов А и В навстречу друг другу одновременно выехали мотоциклист и велосипедист. Мотоциклист приехал в город В на 10 часов раньше, чем велосипедист приехал в город А, а встретились они через 3 часа 45 минут после выезда. Сколько часов затратил на путь из города В в город А велосипедист? */

	let n20=sl(1, 10, 1);
	let n38=sl(1, 3, 1);
	let n43=sl(1, 45, 1);
	let n00=0;

	//genAssert(,''); //Заготовочка!
	//genAssertZ1000(,''); //Заготовочка!

	let the_humanSettlementDestination = sklonlxkand(decor.humanSettlementDestination.iz()); // ["пункт","город","село","деревня"]
	let the_vehicleRacingOnRoad = sklonlxkand(decor.vehicleRacingOnRoad.iz(2)); // ["автомобиль","мотоцикл","велосипед","электросамокат","гироскутер","мотоциклист","велосипедист","машина","гонщик","грузовик","автомобилист"]

	//let   = sklonlxkand([].iz()); // Заготовочка!

	NAtask.setTask({
		text:
			'Из ' + the_humanSettlementDestination.rm +' А и В навстречу друг другу одновременно выехали ' + the_vehicleRacingOnRoad[1].ie +' и ' + the_vehicleRacingOnRoad[0].ie +'. ' + the_vehicleRacingOnRoad[1].ie.toZagl() +' приехал в ' + the_humanSettlementDestination.ie +' В на ' + chislitlx(n20, 'час') + ' раньше, '+
			'чем ' + the_vehicleRacingOnRoad[0].ie +' приехал в ' + the_humanSettlementDestination.ie +' А, а встретились они через ' + chislitlx(n38, 'час') + ' ' + chislitlx(n43, 'минута') + ' после выезда. '+
			'Сколько часов затратил на путь из ' + the_humanSettlementDestination.re +' В в ' + the_humanSettlementDestination.ie +' А ' + the_vehicleRacingOnRoad[0].ie +'?',
		answers: n00,
		authors: [''],
	});
	NAtask.modifiers.allDecimalsToStandard(/*true*/);
}, 2000);})();
// РешуЕГЭ: 
// 
